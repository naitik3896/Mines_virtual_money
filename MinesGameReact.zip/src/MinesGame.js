import React, { useState, useEffect } from "react";

const GRID_SIZE = 5;
const TOTAL_TILES = GRID_SIZE * GRID_SIZE;

export default function MinesGame() {
  const [balance, setBalance] = useState(
    parseInt(localStorage.getItem("balance")) || 1000
  );
  const [bet, setBet] = useState(10);
  const [mines, setMines] = useState(3);
  const [grid, setGrid] = useState(Array(TOTAL_TILES).fill(null));
  const [mineIndexes, setMineIndexes] = useState([]);
  const [clicked, setClicked] = useState([]);
  const [inGame, setInGame] = useState(false);
  const [multiplier, setMultiplier] = useState(1);

  useEffect(() => {
    localStorage.setItem("balance", balance);
  }, [balance]);

  function generateMines() {
    const mineSet = new Set();
    while (mineSet.size < mines) {
      mineSet.add(Math.floor(Math.random() * TOTAL_TILES));
    }
    return Array.from(mineSet);
  }

  function startGame() {
    if (bet > balance || bet <= 0) return alert("Invalid Bet");
    setBalance(balance - bet);
    setMineIndexes(generateMines());
    setGrid(Array(TOTAL_TILES).fill(null));
    setClicked([]);
    setMultiplier(1);
    setInGame(true);
  }

  function handleTileClick(index) {
    if (!inGame || clicked.includes(index)) return;
    const newClicked = [...clicked, index];
    if (mineIndexes.includes(index)) {
      setGrid((prev) => {
        const newGrid = [...prev];
        newGrid[index] = "💣";
        return newGrid;
      });
      setInGame(false);
      return alert("You hit a mine! 😵");
    } else {
      const reward = Math.round(bet * 0.2);
      setGrid((prev) => {
        const newGrid = [...prev];
        newGrid[index] = "💎";
        return newGrid;
      });
      setClicked(newClicked);
      setMultiplier((prev) => (prev + 0.3).toFixed(2));
    }
  }

  function cashOut() {
    const profit = Math.floor(bet * multiplier);
    setBalance(balance + profit);
    setInGame(false);
    alert(`You cashed out: ₹${profit}`);
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-4">💣 Mines Game</h1>

      <div className="mb-2">Balance: ₹{balance}</div>
      <input
        className="bg-gray-800 border p-2 m-1"
        type="number"
        value={bet}
        onChange={(e) => setBet(parseInt(e.target.value))}
        placeholder="Bet Amount"
      />
      <input
        className="bg-gray-800 border p-2 m-1"
        type="number"
        value={mines}
        onChange={(e) => setMines(parseInt(e.target.value))}
        placeholder="No. of Mines"
        min={1}
        max={TOTAL_TILES - 1}
      />
      <button
        onClick={startGame}
        className="bg-green-600 px-4 py-2 rounded m-1"
        disabled={inGame}
      >
        Start Game
      </button>
      {inGame && (
        <button onClick={cashOut} className="bg-yellow-500 px-4 py-2 rounded m-1">
          Cash Out 💰 (x{multiplier})
        </button>
      )}

      <div
        className="grid grid-cols-5 gap-2 mt-4"
        style={{ maxWidth: "300px" }}
      >
        {grid.map((tile, i) => (
          <div
            key={i}
            onClick={() => handleTileClick(i)}
            className="w-12 h-12 bg-gray-700 flex items-center justify-center text-2xl cursor-pointer rounded"
          >
            {tile || (clicked.includes(i) ? "" : "⬜")}
          </div>
        ))}
      </div>
    </div>
  );
}