import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import MinesGame from './MinesGame';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <MinesGame />
  </React.StrictMode>
);